/*
Empresa: Zasso Brasil
Atividade: E - Teste de L�gica de programa��o
Desenvolvedora: Hagatha Juliato
Data: 01/08/2020
*/

#include<stdio.h>
#include <stdlib.h>

int main() {

	int iniHora, iniMin, finHora, finMin, durHora, durMin = 0;
	
	// Recebimento dos hor�rios do jogo pelo usu�rio
	printf("*** ENTRE COM OS VALORES A SEGUIR (FORMATO 24H) ***\n\n	Hora:Minuto Inicial   ");
	scanf_s(" %d : %d", &iniHora, &iniMin);
	printf("\n	Hora:Minuto Final   ");
	scanf_s(" %d : %d", &finHora, &finMin);

	// C�lculo das horas
	if (iniHora > finHora) { durHora = (24 - iniHora) + finHora; }			// Corre��o caso hora final seja maior que hora inicial (Considerando que HorasMax = 24 -> enunciado)
	else { durHora = finHora - iniHora; }

	// C�lculo dos minutos
	if (iniMin > finMin) { durMin = (60 - iniMin) + finMin; }				// Corre��o caso minuto final seja maior que minuto inicial (Considerando que MinutosMin = 1 -> enunciado)
	else { durMin = finMin - iniMin; }

	// Sa�da da dura��o total
	printf("\n\n	O JOGO DUROU %d HORA(S) E %d MINUTO(S)\n\n", durHora, durMin);

	return 0;
}